$mailacc = "example@example.com";

$subject = "Hello";

$message = "
<html>
<head>
  <title>Test Mail</title>
</head>
<body>
    <p><a href='http://stackoverflow.com'>Open Link</a></p>
</body>
</html>
";

$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= 'From: Noreply <noreply@example.com>' . "\r\n";

$mail = mail($mailacc, $subject, $message, $headers);